package edu.ics211.h02;

/**
 * Represents a BeerType.
 *
 * @author Cam Moore
 *
 */
public enum BeerType {
  INDIA_PALE_ALE, PILSNER, BOHEMIAN_PILSNER
}